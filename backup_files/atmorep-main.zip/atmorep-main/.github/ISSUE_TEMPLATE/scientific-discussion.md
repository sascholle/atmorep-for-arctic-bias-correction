---
name: Scientific discussion
about: discuss scientific developments
title: "[SCIENTIFIC]"
labels: ''
assignees: ''

---

**Describe the topic**
A clear and concise description of the scientific topic you want to discuss.

**Describe the technical developments**
A clear and concise description of the technical advancements needed to make this happen. Ideally as bullet points

**Additional context**
Add any other context or screenshots about the discussed topic here. 

** Related issues**
link here the issues related to this scientific discussion.
